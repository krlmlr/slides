library(testthat)
library(ansistrings)

test_check("ansistrings")
