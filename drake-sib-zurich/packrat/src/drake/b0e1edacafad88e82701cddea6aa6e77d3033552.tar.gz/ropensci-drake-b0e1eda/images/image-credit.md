The files [infographic.svg](https://github.com/ropensci/drake/blob/master/images/infographic.svg) and [infographic-font.svg](https://github.com/ropensci/drake/blob/master/images/infographic-font.svg) were created using clipart released under the Creative Commons License:
- "multiple" by Hea Poh Lin from the [Noun Project](https://thenounproject.com/)
- "replay" by Sylvain A. from the [Noun Project](https://thenounproject.com/)
- "checkmark" by Ananth from the [Noun Project](https://thenounproject.com/)
