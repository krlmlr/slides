#' @examples
#' chopped_meat <- chop("raw_meat.csv")
#' chopped_meat
#' fry(chopped_meat, with = "vegetables")
#' combine("diced cucumber", "cut tomatoes", name = "salad")
"_PACKAGE"
