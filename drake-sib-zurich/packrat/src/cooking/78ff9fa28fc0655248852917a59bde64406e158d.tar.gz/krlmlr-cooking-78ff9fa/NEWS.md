## cooking 0.0-5 (2018-03-02)

- Adjectives are formatted in italics in the printed output.
- Printing adds terminal newline to fix printing in the R console (#1).


## cooking 0.0-4 (2017-04-10)

- Use the contents of an existing file to determine the provenance.


## cooking 0.0-3 (2017-04-07)

- Minor tweaks.
- Test with Travis CI.


## cooking 0.0-2 (2017-04-07)

- Add `buy()` action and `supermarket()` source.


## cooking 0.0-1 (2017-04-07)

- Initial release: actions `peel()`, `chop()`, `fry()`, `cook()`, and `combine()`.
