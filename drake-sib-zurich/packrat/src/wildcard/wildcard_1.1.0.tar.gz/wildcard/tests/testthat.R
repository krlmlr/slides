library(testthat)
library(wildcard)

test_check("wildcard")
