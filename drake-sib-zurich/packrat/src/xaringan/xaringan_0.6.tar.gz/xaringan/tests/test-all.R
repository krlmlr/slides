library(testit)
test_pkg('xaringan')
